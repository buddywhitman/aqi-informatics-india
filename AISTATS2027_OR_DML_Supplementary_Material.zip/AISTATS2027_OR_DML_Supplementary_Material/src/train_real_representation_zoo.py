r"""
train_real_representation_zoo.py
================================
Trains REAL neural sequence encoders (GRU, Causal Transformer, Linear SSM)
and Gaussian HMM on sequence regimes under disentangled distribution shifts:
  - Shift A: Transition-only shift (persistence increases: rho -> 0.96)
  - Shift B: Emission-only shift (proxy separation degrades: Delta_Z -> 1.0)
  - Shift C: Compound shift (both transition and emission shift)

Downstream Reliability Evaluation:
  1. Fit a genuine downstream predictive model f^{(m)} on training data
     using the representation m's inferred latent state gamma_t and controls X_t.
  2. Evaluate out-of-sample downstream forecasting error on Shift C (compound shift):
     L_{t+h} = (Y_{t+h} - \hat{Y}_{t+h}^{(m)})^2.
  3. Predict extreme downstream failure (top 10% loss) using:
     - Task-conditioned difficulty D_t = H(\gamma_t) / \lambda_min(J_t)
     - Raw state entropy H_t = H(\gamma_t)
  4. Perform multi-seed evaluation with bootstrap 95% confidence intervals
     and paired bootstrap hypothesis tests (\Delta AUC = AUC(D) - AUC(H)).
  5. Measure Monotone Difficulty Alignment (MDA) via rank correlation \rho(D, L).
"""

import os
import sys
import time
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
from scipy.stats import spearmanr
from sklearn.linear_model import Ridge
from sklearn.metrics import f1_score, brier_score_loss, roc_auc_score, precision_recall_curve, auc

project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from src.regime_intelligence import (
    GaussianHMMEncoder,
    GRURegimeEncoder,
    TransformerRegimeEncoder,
    SSMRegimeEncoder
)


def compute_nll(probs: np.ndarray, labels: np.ndarray, eps: float = 1e-12) -> float:
    """Categorical Negative Log-Likelihood (Cross-Entropy)."""
    p_clipped = np.clip(probs, eps, 1.0)
    return float(-np.mean(np.log(p_clipped[np.arange(len(labels)), labels])))


def compute_ece(probs: np.ndarray, labels: np.ndarray, n_bins: int = 10) -> float:
    """Expected Calibration Error."""
    K = probs.shape[1]
    ece = 0.0
    for k in range(K):
        p = probs[:, k]
        y = (labels == k).astype(float)
        bins = np.linspace(0, 1, n_bins + 1)
        for i in range(n_bins):
            m = (p >= bins[i]) & (p < bins[i + 1])
            if m.sum() > 0:
                ece += m.sum() / len(p) * abs(p[m].mean() - y[m].mean())
    return float(ece / K)


def compute_mda(difficulty: np.ndarray, losses: np.ndarray) -> float:
    """
    Monotone Difficulty Alignment (MDA):
    Spearman rank correlation between task difficulty D_t and empirical downstream loss L_t.
    """
    rho, _ = spearmanr(difficulty, losses)
    return float(rho) if not np.isnan(rho) else 0.0


def moving_block_bootstrap_auc(y_true, score_A, score_B, n_boot=1000, block_length=24, rng=None):
    r"""
    Moving-Block Bootstrap (MBB) for temporally dependent time series.
    Preserves Markov/temporal autocorrelation by resampling contiguous blocks of length L=24.
    Computes 95% CIs for AUC(A), AUC(B), and paired difference \Delta AUC with empirical p-value.
    """
    if rng is None:
        rng = np.random.default_rng(42)
    n = len(y_true)
    L = min(max(4, int(block_length)), n // 2)
    n_blocks = int(np.ceil(n / L))
    max_start = n - L + 1

    diffs = []
    auc_A_list = []
    auc_B_list = []
    for _ in range(n_boot):
        starts = rng.integers(0, max_start, size=n_blocks)
        idx = np.concatenate([np.arange(s, s + L) for s in starts])[:n]
        y_b = y_true[idx]
        if len(np.unique(y_b)) < 2:
            continue
        a = roc_auc_score(y_b, score_A[idx])
        b = roc_auc_score(y_b, score_B[idx])
        auc_A_list.append(a)
        auc_B_list.append(b)
        diffs.append(a - b)

    if len(auc_A_list) < 10:
        return (0.5, 0.5), (0.5, 0.5), (0.0, 0.0), 1.0

    ci_A = (float(np.percentile(auc_A_list, 2.5)), float(np.percentile(auc_A_list, 97.5)))
    ci_B = (float(np.percentile(auc_B_list, 2.5)), float(np.percentile(auc_B_list, 97.5)))
    ci_diff = (float(np.percentile(diffs, 2.5)), float(np.percentile(diffs, 97.5)))
    p_val = float(np.mean(np.array(diffs) <= 0) if np.mean(diffs) > 0 else np.mean(np.array(diffs) >= 0))
    return ci_A, ci_B, ci_diff, p_val


def generate_regime_stream(
    N: int,
    K: int = 2,
    rho: float = 0.85,
    Delta_Z: float = 3.5,
    shift_mode: str = "none",
    seed: int = 42
):
    """
    Generates non-stationary sequence stream with disentangled distribution shifts:
      - 'none': In-distribution (rho=0.85, Delta_Z=3.5)
      - 'shift_a': Transition-only shift (persistence increases: rho -> 0.96)
      - 'shift_b': Emission-only shift (proxy separation degrades: Delta_Z -> 1.0)
      - 'shift_c': Compound shift (rho -> 0.96 and Delta_Z -> 1.0)
    """
    rng = np.random.default_rng(seed)

    cur_rho = rho
    cur_delta = Delta_Z

    if shift_mode == "shift_a":
        cur_rho = 0.96
    elif shift_mode == "shift_b":
        cur_delta = 1.0
    elif shift_mode == "shift_c":
        cur_rho = 0.96
        cur_delta = 1.0

    off = max(1e-4, (1.0 - cur_rho) / (K - 1))
    A = np.full((K, K), off)
    np.fill_diagonal(A, cur_rho)

    mu_Z = np.array([[-cur_delta, 0.0], [cur_delta, 0.0]])

    S = np.zeros(N, dtype=int)
    S[0] = rng.integers(K)
    for t in range(1, N):
        S[t] = rng.choice(K, p=A[S[t - 1]])

    Z = mu_Z[S] + rng.normal(0, 1.0, (N, 2))
    
    # Weather controls X: AR(1) driven by S
    X = np.zeros((N, 2))
    for t in range(1, N):
        X[t] = 0.65 * X[t - 1] + rng.normal(0, 0.5, 2) + 0.5 * (S[t] - 0.5)

    # Treatment T and Outcome Y
    T = 2.0 * (1 - S) + 6.0 * S + 0.8 * X[:, 0] - 0.5 * X[:, 1] + rng.normal(0, 1.0, N)
    theta_true = np.array([0.75, 2.50])
    Y = theta_true[S] * T + 1.2 * X[:, 0] + 0.6 * X[:, 1] + rng.normal(0, 0.8, N)

    return Z, S, X, T, Y


def run_single_seed(seed: int, device: torch.device):
    seq_len = 16
    N_tr = 1500
    N_eval = 1200

    Z_tr, S_tr, X_tr, T_tr, Y_tr = generate_regime_stream(N_tr, shift_mode="none", seed=seed)
    Z_in, S_in, X_in, T_in, Y_in = generate_regime_stream(N_eval, shift_mode="none", seed=seed + 1000)
    Z_sa, S_sa, X_sa, T_sa, Y_sa = generate_regime_stream(N_eval, shift_mode="shift_a", seed=seed + 2000)
    Z_sb, S_sb, X_sb, T_sb, Y_sb = generate_regime_stream(N_eval, shift_mode="shift_b", seed=seed + 3000)
    Z_sc, S_sc, X_sc, T_sc, Y_sc = generate_regime_stream(N_eval, shift_mode="shift_c", seed=seed + 4000)

    def make_windows(Z, S):
        X_w = np.array([Z[t - seq_len:t] for t in range(seq_len, len(Z))])
        y_w = S[seq_len - 1 : len(Z) - 1]
        return torch.tensor(X_w, dtype=torch.float32), torch.tensor(y_w, dtype=torch.long)

    X_tr_w, y_tr_w = make_windows(Z_tr, S_tr)
    X_in_w, y_in_w = make_windows(Z_in, S_in)
    X_sa_w, y_sa_w = make_windows(Z_sa, S_sa)
    X_sb_w, y_sb_w = make_windows(Z_sb, S_sb)
    X_sc_w, y_sc_w = make_windows(Z_sc, S_sc)

    X_tr_dev, y_tr_dev = X_tr_w.to(device), y_tr_w.to(device)

    # 1. Fit Gaussian HMM
    hmm = GaussianHMMEncoder(n_regimes=2, random_state=seed)
    hmm.fit(Z_tr)
    p_hmm_tr = hmm.filter_forward(Z_tr)[seq_len - 1 : len(Z_tr) - 1]
    p_hmm_in = hmm.filter_forward(Z_in)[seq_len - 1 : len(Z_in) - 1]
    p_hmm_sa = hmm.filter_forward(Z_sa)[seq_len - 1 : len(Z_sa) - 1]
    p_hmm_sb = hmm.filter_forward(Z_sb)[seq_len - 1 : len(Z_sb) - 1]
    p_hmm_sc = hmm.filter_forward(Z_sc)[seq_len - 1 : len(Z_sc) - 1]

    # Helper for neural training
    def train_neural(model, lr=0.01, epochs=16):
        model.to(device)
        optimizer = optim.Adam(model.parameters(), lr=lr, weight_decay=1e-4)
        criterion = nn.NLLLoss()

        model.train()
        num_samples = len(X_tr_dev)
        for epoch in range(epochs):
            perm = torch.randperm(num_samples, device=device)
            for i in range(0, num_samples, 64):
                idx = perm[i : i + 64]
                optimizer.zero_grad()
                out = model(X_tr_dev[idx])
                loss = criterion(torch.log(out + 1e-12), y_tr_dev[idx])
                loss.backward()
                optimizer.step()

        model.eval()
        with torch.no_grad():
            p_tr = model(X_tr_dev).cpu().numpy()
            p_in = model(X_in_w.to(device)).cpu().numpy()
            p_sa = model(X_sa_w.to(device)).cpu().numpy()
            p_sb = model(X_sb_w.to(device)).cpu().numpy()
            p_sc = model(X_sc_w.to(device)).cpu().numpy()
        return p_tr, p_in, p_sa, p_sb, p_sc

    # 2. Neural GRU
    gru = GRURegimeEncoder(input_dim=2, hidden_dim=32, n_regimes=2)
    p_gru_tr, p_gru_in, p_gru_sa, p_gru_sb, p_gru_sc = train_neural(gru, lr=0.01)

    # 3. Causal Transformer
    tf = TransformerRegimeEncoder(input_dim=2, embed_dim=32, num_heads=2, n_regimes=2)
    p_tf_tr, p_tf_in, p_tf_sa, p_tf_sb, p_tf_sc = train_neural(tf, lr=0.008)

    # 4. Linear SSM
    ssm = SSMRegimeEncoder(input_dim=2, state_dim=16, n_regimes=2)
    p_ssm_tr, p_ssm_in, p_ssm_sa, p_ssm_sb, p_ssm_sc = train_neural(ssm, lr=0.01)

    models_dict = {
        "Gaussian HMM (Causal Filter)": {"tr": p_hmm_tr, "in": p_hmm_in, "sa": p_hmm_sa, "sb": p_hmm_sb, "sc": p_hmm_sc},
        "Neural GRU Encoder": {"tr": p_gru_tr, "in": p_gru_in, "sa": p_gru_sa, "sb": p_gru_sb, "sc": p_gru_sc},
        "Causal Transformer Encoder": {"tr": p_tf_tr, "in": p_tf_in, "sa": p_tf_sa, "sb": p_tf_sb, "sc": p_tf_sc},
        "Linear State Space Model (SSM)": {"tr": p_ssm_tr, "in": p_ssm_in, "sa": p_ssm_sa, "sb": p_ssm_sb, "sc": p_ssm_sc}
    }

    # Slice evaluation target variables to match seq_len windowing
    sl = slice(seq_len - 1, N_eval - 1)
    sl_tr = slice(seq_len - 1, N_tr - 1)

    targets = {
        "tr": (y_tr_w.numpy(), X_tr[sl_tr], T_tr[sl_tr], Y_tr[sl_tr]),
        "in": (y_in_w.numpy(), X_in[sl], T_in[sl], Y_in[sl]),
        "sa": (y_sa_w.numpy(), X_sa[sl], T_sa[sl], Y_sa[sl]),
        "sb": (y_sb_w.numpy(), X_sb[sl], T_sb[sl], Y_sb[sl]),
        "sc": (y_sc_w.numpy(), X_sc[sl], T_sc[sl], Y_sc[sl])
    }

    # Evaluate shifts
    shift_results = {}
    rel_results = {}

    for name, p_m in models_dict.items():
        # Classification F1 across shifts
        f1_in = f1_score(targets["in"][0], np.argmax(p_m["in"], 1), average="macro")
        f1_sa = f1_score(targets["sa"][0], np.argmax(p_m["sa"], 1), average="macro")
        f1_sb = f1_score(targets["sb"][0], np.argmax(p_m["sb"], 1), average="macro")
        f1_sc = f1_score(targets["sc"][0], np.argmax(p_m["sc"], 1), average="macro")
        ece_in = compute_ece(p_m["in"], targets["in"][0])
        ece_sc = compute_ece(p_m["sc"], targets["sc"][0])
        brier_in = np.mean([brier_score_loss(targets["in"][0] == k, p_m["in"][:, k]) for k in range(2)])
        brier_sc = np.mean([brier_score_loss(targets["sc"][0] == k, p_m["sc"][:, k]) for k in range(2)])
        nll_in = compute_nll(p_m["in"], targets["in"][0])
        nll_sc = compute_nll(p_m["sc"], targets["sc"][0])

        shift_results[name] = {
            "InDist_F1": f1_in,
            "ShiftA_Transition_F1": f1_sa,
            "ShiftB_Emission_F1": f1_sb,
            "ShiftC_Compound_F1": f1_sc,
            "Compound_Gap_F1": f1_in - f1_sc,
            "InDist_ECE": ece_in,
            "ShiftC_ECE": ece_sc,
            "InDist_Brier": brier_in,
            "ShiftC_Brier": brier_sc,
            "InDist_NLL": nll_in,
            "ShiftC_NLL": nll_sc
        }

        # ── Downstream Model Training & Failure Anticipation Evaluation ─────
        # Fit downstream Ridge regression f^{(m)} strictly on training split:
        # Features: [gamma_0, gamma_1, T, gamma_0*T, gamma_1*T, X_0, X_1]
        _, X_tr_s, T_tr_s, Y_tr_s = targets["tr"]
        p_tr_m = p_m["tr"]
        Phi_tr = np.column_stack([
            p_tr_m[:, 0], p_tr_m[:, 1],
            T_tr_s,
            p_tr_m[:, 0] * T_tr_s, p_tr_m[:, 1] * T_tr_s,
            X_tr_s[:, 0], X_tr_s[:, 1]
        ])
        downstream_model = Ridge(alpha=1.0)
        downstream_model.fit(Phi_tr, Y_tr_s)

        # Evaluate on Shift C (compound shift) out-of-sample
        y_sc_t, X_sc_s, T_sc_s, Y_sc_s = targets["sc"]
        p_sc_m = p_m["sc"]
        Phi_sc = np.column_stack([
            p_sc_m[:, 0], p_sc_m[:, 1],
            T_sc_s,
            p_sc_m[:, 0] * T_sc_s, p_sc_m[:, 1] * T_sc_s,
            X_sc_s[:, 0], X_sc_s[:, 1]
        ])
        Y_hat = downstream_model.predict(Phi_sc)
        downstream_loss = (Y_sc_s - Y_hat) ** 2

        # ── Exact Coupled Regime Gram Matrix J_t (Theorem 4 & Algorithm 1) ──
        # Estimate regime treatment nuisances m_k(X) = E[T | X, S=k] on training split
        reg_m0 = Ridge(alpha=1.0)
        w0 = np.clip(p_tr_m[:, 0], 1e-4, 1.0)
        reg_m0.fit(X_tr_s, T_tr_s, sample_weight=w0)

        reg_m1 = Ridge(alpha=1.0)
        w1 = np.clip(p_tr_m[:, 1], 1e-4, 1.0)
        reg_m1.fit(X_tr_s, T_tr_s, sample_weight=w1)

        # Form exact residualized treatments \tilde{T}_{tk} on Shift C split
        T_res0 = T_sc_s - reg_m0.predict(X_sc_s)
        T_res1 = T_sc_s - reg_m1.predict(X_sc_s)

        # Rolling Gram entries over window w=48:
        # J_t[j, k] = (1/w) * sum_{s=t-w+1}^t gamma_{sj} * gamma_{sk} * \tilde{T}_{sj} * \tilde{T}_{sk}
        w = 48
        s00 = pd.Series(p_sc_m[:, 0]**2 * T_res0**2).rolling(w, min_periods=1).mean().values
        s11 = pd.Series(p_sc_m[:, 1]**2 * T_res1**2).rolling(w, min_periods=1).mean().values
        s01 = pd.Series(p_sc_m[:, 0] * p_sc_m[:, 1] * T_res0 * T_res1).rolling(w, min_periods=1).mean().values

        trace = s00 + s11
        disc = np.sqrt(np.maximum((s00 - s11)**2 + 4.0 * (s01**2), 0.0))
        lambda_min_t = np.maximum(0.5 * (trace - disc), 1e-4)

        gamma_safe = np.clip(p_sc_m, 1e-12, 1.0)
        H_t = -np.sum(gamma_safe * np.log(gamma_safe), axis=1) / np.log(2.0)
        TaskCond_t = 1.0 / lambda_min_t
        D_t = H_t / lambda_min_t

        # Next-step lead-1 failure anticipation with FROZEN CALIBRATION THRESHOLD
        # Calibration partition: first 400 steps (35% of evaluation stream)
        # Test partition: steps 400 to end (frozen out-of-sample evaluation)
        cal_len = 400
        cal_loss = downstream_loss[:cal_len]
        fail_thresh = float(np.percentile(cal_loss, 90))

        test_loss = downstream_loss[cal_len:]
        test_lead_loss = test_loss[1:]
        fail_bin = (test_lead_loss > fail_thresh).astype(int)

        D_lead = D_t[cal_len:-1]
        H_lead = H_t[cal_len:-1]
        Cond_lead = TaskCond_t[cal_len:-1]

        auc_D = roc_auc_score(fail_bin, D_lead)
        auc_H = roc_auc_score(fail_bin, H_lead)
        auc_Cond = roc_auc_score(fail_bin, Cond_lead)

        pr_D = auc(*precision_recall_curve(fail_bin, D_lead)[1::-1])
        pr_H = auc(*precision_recall_curve(fail_bin, H_lead)[1::-1])
        pr_Cond = auc(*precision_recall_curve(fail_bin, Cond_lead)[1::-1])

        mda_D = compute_mda(D_lead, test_lead_loss)
        mda_H = compute_mda(H_lead, test_lead_loss)
        mda_Cond = compute_mda(Cond_lead, test_lead_loss)

        # Nested linear regressions of downstream loss
        var_tot = float(np.var(test_lead_loss)) + 1e-12
        r2_H = float(np.corrcoef(H_lead, test_lead_loss)[0, 1]**2) if np.std(H_lead) > 1e-6 else 0.0
        r2_Cond = float(np.corrcoef(Cond_lead, test_lead_loss)[0, 1]**2) if np.std(Cond_lead) > 1e-6 else 0.0
        r2_D = float(np.corrcoef(D_lead, test_lead_loss)[0, 1]**2) if np.std(D_lead) > 1e-6 else 0.0

        floor_sens = {}
        for ef in [1e-6, 1e-5, 1e-4, 1e-3]:
            lmin_f = np.maximum(0.5 * (trace - disc), ef)
            d_f = (H_t / lmin_f)[cal_len:-1]
            floor_sens[f"Floor_{ef:.0e}"] = roc_auc_score(fail_bin, d_f)

        mbb_sens = {}
        for block_l in [12, 24, 48, 72]:
            ci_D_l, _, _, _ = moving_block_bootstrap_auc(
                fail_bin, D_lead, H_lead, n_boot=1000, block_length=block_l, rng=np.random.default_rng(seed)
            )
            mbb_sens[f"MBB_L{block_l}_low"] = ci_D_l[0]
            mbb_sens[f"MBB_L{block_l}_high"] = ci_D_l[1]

        ci_D, ci_H, ci_diff, p_diff = moving_block_bootstrap_auc(
            fail_bin, D_lead, H_lead, n_boot=1000, block_length=24, rng=np.random.default_rng(seed)
        )

        rel_results[name] = {
            "ShiftC_F1": f1_sc,
            "Reliability_ROC_AUC_D": auc_D,
            **floor_sens,
            **mbb_sens,
            "AUC_D_CI_low": ci_D[0],
            "AUC_D_CI_high": ci_D[1],
            "Reliability_PR_AUC_D": pr_D,
            "Baseline_ROC_AUC_H": auc_H,
            "AUC_H_CI_low": ci_H[0],
            "AUC_H_CI_high": ci_H[1],
            "Conditioning_ROC_AUC": auc_Cond,
            "AUC_Advantage_D_over_H": auc_D - auc_H,
            "Delta_AUC_CI_low": ci_diff[0],
            "Delta_AUC_CI_high": ci_diff[1],
            "p_value_diff": p_diff,
            "MDA_D": mda_D,
            "MDA_H": mda_H,
            "MDA_Cond": mda_Cond,
            "R2_Loss_H": r2_H,
            "R2_Loss_Cond": r2_Cond,
            "R2_Loss_D": r2_D
        }

    return shift_results, rel_results


def run_real_representation_zoo():
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print("=" * 80)
    print(f"TRAINING REAL LATENT REPRESENTATION ZOO WITH DOWNSTREAM LEARNING ON {device}")
    print("=" * 80)

    seeds = [42, 43, 44, 45, 46]
    all_shifts = []
    all_rel = []

    for s in seeds:
        print(f"\n--- Running Seed {s} ---")
        sr, rr = run_single_seed(s, device)
        all_shifts.append(sr)
        all_rel.append(rr)

    # Aggregate across seeds
    architectures = list(all_shifts[0].keys())
    
    agg_shifts = []
    for arch in architectures:
        row = {"Architecture": arch}
        for metric in all_shifts[0][arch].keys():
            vals = [all_shifts[i][arch][metric] for i in range(len(seeds))]
            row[metric] = round(float(np.mean(vals)), 4)
            row[f"{metric}_Std"] = round(float(np.std(vals)), 4)
        agg_shifts.append(row)

    df_shifts = pd.DataFrame(agg_shifts)
    os.makedirs("reports", exist_ok=True)
    df_shifts.to_csv("reports/representation_zoo_disentangled_shifts.csv", index=False)

    agg_rel = []
    for arch in architectures:
        row = {"Architecture": arch}
        for metric in all_rel[0][arch].keys():
            vals = [all_rel[i][arch][metric] for i in range(len(seeds))]
            row[metric] = round(float(np.mean(vals)), 4)
            row[f"{metric}_Std"] = round(float(np.std(vals)), 4)
        agg_rel.append(row)

    df_rel = pd.DataFrame(agg_rel)
    df_rel.to_csv("reports/representation_zoo_reliability_auc.csv", index=False)

    # Floor sensitivity report across numerical thresholds
    floor_rows = []
    for arch in architectures:
        f_row = {"Architecture": arch}
        for ef in ["Floor_1e-06", "Floor_1e-05", "Floor_1e-04", "Floor_1e-03"]:
            vals = [all_rel[i][arch][ef] for i in range(len(seeds))]
            f_row[f"{ef}_Mean"] = round(float(np.mean(vals)), 4)
            f_row[f"{ef}_Std"] = round(float(np.std(vals)), 4)
        floor_rows.append(f_row)
    pd.DataFrame(floor_rows).to_csv("reports/representation_zoo_floor_sensitivity.csv", index=False)

    # MBB block-length sensitivity report across L in {12, 24, 48, 72}
    mbb_rows = []
    for arch in architectures:
        m_row = {"Architecture": arch}
        for bl in [12, 24, 48, 72]:
            lows = [all_rel[i][arch][f"MBB_L{bl}_low"] for i in range(len(seeds))]
            highs = [all_rel[i][arch][f"MBB_L{bl}_high"] for i in range(len(seeds))]
            m_row[f"L{bl}_95CI_low"] = round(float(np.mean(lows)), 4)
            m_row[f"L{bl}_95CI_high"] = round(float(np.mean(highs)), 4)
            m_row[f"L{bl}_CI_width"] = round(float(np.mean(highs) - np.mean(lows)), 4)
        mbb_rows.append(m_row)
    pd.DataFrame(mbb_rows).to_csv("reports/representation_zoo_mbb_sensitivity.csv", index=False)

    # Hierarchical seed-level correlation analysis: seeds as independent replication units
    # Evaluates within-seed rank correlations and tests via cluster permutations and seed bootstrap
    rhos_f1, rhos_ece, rhos_nll = [], [], []
    for i, s in enumerate(seeds):
        f1_s = [all_shifts[i][arch]["ShiftC_Compound_F1"] for arch in architectures]
        ece_s = [all_shifts[i][arch]["ShiftC_ECE"] for arch in architectures]
        nll_s = [all_shifts[i][arch]["ShiftC_NLL"] for arch in architectures]
        auc_s = [all_rel[i][arch]["Reliability_ROC_AUC_D"] for arch in architectures]

        r_f1, _ = spearmanr(f1_s, auc_s)
        r_ece, _ = spearmanr(ece_s, auc_s)
        r_nll, _ = spearmanr(nll_s, auc_s)
        rhos_f1.append(float(r_f1))
        rhos_ece.append(float(r_ece))
        rhos_nll.append(float(r_nll))

    mean_rho_f1 = float(np.mean(rhos_f1))
    mean_rho_ece = float(np.mean(rhos_ece))
    mean_rho_nll = float(np.mean(rhos_nll))

    se_f1 = float(np.std(rhos_f1) / np.sqrt(len(seeds)))
    se_ece = float(np.std(rhos_ece) / np.sqrt(len(seeds)))
    se_nll = float(np.std(rhos_nll) / np.sqrt(len(seeds)))

    # Cluster-preserving permutation test across independent seed units (10,000 permutations)
    rng_perm = np.random.default_rng(42)
    B_perm = 10000
    perm_f1, perm_ece, perm_nll = [], [], []
    for _ in range(B_perm):
        pf_list, pe_list, pn_list = [], [], []
        for i in range(len(seeds)):
            perm_idx = rng_perm.permutation(len(architectures))
            f1_s = np.array([all_shifts[i][arch]["ShiftC_Compound_F1"] for arch in architectures])[perm_idx]
            ece_s = np.array([all_shifts[i][arch]["ShiftC_ECE"] for arch in architectures])[perm_idx]
            nll_s = np.array([all_shifts[i][arch]["ShiftC_NLL"] for arch in architectures])[perm_idx]
            auc_s = np.array([all_rel[i][arch]["Reliability_ROC_AUC_D"] for arch in architectures])

            pf_list.append(spearmanr(f1_s, auc_s)[0])
            pe_list.append(spearmanr(ece_s, auc_s)[0])
            pn_list.append(spearmanr(nll_s, auc_s)[0])
        perm_f1.append(np.mean(pf_list))
        perm_ece.append(np.mean(pe_list))
        perm_nll.append(np.mean(pn_list))

    p_val_f1 = float(np.mean(np.abs(perm_f1) >= np.abs(mean_rho_f1)))
    p_val_ece = float(np.mean(np.array(perm_ece) <= mean_rho_ece))
    p_val_nll = float(np.mean(np.array(perm_nll) <= mean_rho_nll))

    # Seed-level cluster bootstrap 95% CIs (10,000 resamples of seed units)
    boot_f1, boot_ece, boot_nll = [], [], []
    for _ in range(10000):
        b_idx = rng_perm.integers(0, len(seeds), size=len(seeds))
        boot_f1.append(np.mean([rhos_f1[b] for b in b_idx]))
        boot_ece.append(np.mean([rhos_ece[b] for b in b_idx]))
        boot_nll.append(np.mean([rhos_nll[b] for b in b_idx]))

    ci_f1 = (float(np.percentile(boot_f1, 2.5)), float(np.percentile(boot_f1, 97.5)))
    ci_ece = (float(np.percentile(boot_ece, 2.5)), float(np.percentile(boot_ece, 97.5)))
    ci_nll = (float(np.percentile(boot_nll, 2.5)), float(np.percentile(boot_nll, 97.5)))

    df_corrs = pd.DataFrame([
        {
            "Metric": "Classification F1",
            "Mean_Within_Seed_Spearman_rho": round(mean_rho_f1, 4),
            "Clustered_SE": round(se_f1, 4),
            "Seed_Bootstrap_95CI_low": round(ci_f1[0], 4),
            "Seed_Bootstrap_95CI_high": round(ci_f1[1], 4),
            "Cluster_Permutation_p_value": round(p_val_f1, 4)
        },
        {
            "Metric": "Calibration ECE",
            "Mean_Within_Seed_Spearman_rho": round(mean_rho_ece, 4),
            "Clustered_SE": round(se_ece, 4),
            "Seed_Bootstrap_95CI_low": round(ci_ece[0], 4),
            "Seed_Bootstrap_95CI_high": round(ci_ece[1], 4),
            "Cluster_Permutation_p_value": round(p_val_ece, 4)
        },
        {
            "Metric": "Log-Loss NLL",
            "Mean_Within_Seed_Spearman_rho": round(mean_rho_nll, 4),
            "Clustered_SE": round(se_nll, 4),
            "Seed_Bootstrap_95CI_low": round(ci_nll[0], 4),
            "Seed_Bootstrap_95CI_high": round(ci_nll[1], 4),
            "Cluster_Permutation_p_value": round(p_val_nll, 4)
        },
    ])
    df_corrs.to_csv("reports/representation_zoo_reliability_correlations.csv", index=False)

    # Canonical latent_regime_bench_models.csv for backward compatibility
    canon_rows = []
    for r in agg_shifts:
        canon_rows.append({
            "Architecture": r["Architecture"],
            "InDist_Macro_F1": r["InDist_F1"],
            "OOD_Shift_F1": r["ShiftC_Compound_F1"],
            "F1_Generalization_Gap": r["Compound_Gap_F1"],
            "InDist_Brier": r["InDist_Brier"],
            "OOD_Shift_Brier": r["ShiftC_Brier"],
            "InDist_ECE": r["InDist_ECE"],
            "OOD_Shift_ECE": r["ShiftC_ECE"],
            "InDist_NLL": r["InDist_NLL"],
            "OOD_Shift_NLL": r["ShiftC_NLL"]
        })
    pd.DataFrame(canon_rows).to_csv("reports/latent_regime_bench_models.csv", index=False)

    print("\n" + "=" * 80)
    print("DISENTANGLED DISTRIBUTION SHIFTS (MEAN ACROSS 5 SEEDS)")
    print("=" * 80)
    print(df_shifts[["Architecture", "InDist_F1", "ShiftA_Transition_F1", "ShiftB_Emission_F1", "ShiftC_Compound_F1", "Compound_Gap_F1", "ShiftC_ECE"]].to_string(index=False))

    print("\n" + "=" * 80)
    print("REPRESENTATION ACCURACY VS DOWNSTREAM RELIABILITY (MEAN ACROSS 5 SEEDS)")
    print("=" * 80)
    print(df_rel[["Architecture", "ShiftC_F1", "Reliability_ROC_AUC_D", "Baseline_ROC_AUC_H", "AUC_Advantage_D_over_H", "MDA_D"]].to_string(index=False))

    return df_shifts, df_rel


if __name__ == "__main__":
    run_real_representation_zoo()
